/*
 * Brown FSAE Shift System
 * Stephen Weinreich
 * Fall 2013 / Spring 2014
 *
 * Using the Timer-Counter to create a 1ms tick.
 *
 */

#ifndef tc_shift2014
#define tc_shift2014
#include <stdint.h>

void tc_init(void);

uint32_t millis(void);

#endif