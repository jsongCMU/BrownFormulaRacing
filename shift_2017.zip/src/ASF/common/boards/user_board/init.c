/*
 * Brown FSAE Shift System
 * Stephen Weinreich
 * Fall 2013 / Spring 2014
 *
 * Initialize the board
 */

#include <asf.h>
#include <board.h>
#include <conf_board.h>

#include <asf.h>
#include <board.h>
#include <conf_board.h>
#include <intc.h>
// Add my files
#include "adc_shift2014.h"
#include "usbcdc_shift2014.h"
#include "spi_shift2014.h"
#include "pwm_shift2014.h"
#include "eic_shift2014.h"
#include "tc_shift2014.h"
#include "can_shift2014.h"

void board_init(void) {
	INTC_init_interrupts();		// Initialize interrupt vectors.
	
	// Enable external interrupts, including pullup/pulldown on pins
	gpio_configure_pin(AUTO_UP_2_PIN, AUTO_UP_2_CONFIG);
	gpio_configure_pin(GEAR_POS_PIN, GEAR_POS_CONFIG);
	gpio_configure_pin(AUTO_UP_1_PIN, AUTO_UP_1_CONFIG);
	gpio_configure_pin(DNSHIFT_PIN, DNSHIFT_CONFIG);
	gpio_configure_pin(UPSHIFT_PIN, UPSHIFT_CONFIG);
	gpio_configure_pin(SHIFT_EN_PIN, SHIFT_EN_CONFIG);
	gpio_configure_pin(NEUTRAL_TOG_PIN, NEUTRAL_TOG_CONFIG);
	gpio_configure_pin(SHIFT_PRES_PIN, SHIFT_PRES_CONFIG);
	eic_init_fsae();

	// Enable timer-counter for millis
	tc_init();
	
	// Enable USB CDC for debugging
	usb_cdc_init();
	
	// Start ADC on all eight pins
	adc_init();
	
	// Start SPI and chip select pins
	spi_init();
	gpio_configure_pin(CS_LED_PIN, CS_LED_CONFIG);
	gpio_configure_pin(CS_SEV_SEG_PIN, CS_SEV_SEG_CONFIG);
	
	// Start PWM on the LED brightness pin
	pwm_init_fsae();
	pwm_start(LED_PWM_PIN, LED_PWM_FUNCTION, LED_PWM_ID);
	
	// Configure GPIO pins
	gpio_configure_pin(SHIFT_DOWN_PIN, SHIFT_DOWN_CONFIG);
	gpio_configure_pin(SHIFT_UP_PIN, SHIFT_UP_CONFIG);
	gpio_configure_pin(CLUTCH_1_PIN, CLUTCH_1_CONFIG);
	gpio_configure_pin(CLUTCH_0_PIN, CLUTCH_0_CONFIG);
	gpio_configure_pin(GPIO_X2_PIN, GPIO_X2_CONFIG);
	gpio_configure_pin(GPIO_X1_PIN, GPIO_X1_CONFIG);
	gpio_configure_pin(WOT_PIN, WOT_CONFIG);
	gpio_configure_pin(HWB_PIN, HWB_CONFIG);
	
	// CAN init
	can_init_fsae();
}