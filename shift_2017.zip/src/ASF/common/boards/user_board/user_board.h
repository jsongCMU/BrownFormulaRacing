/*
 * Brown FSAE Shift System
 * Stephen Weinreich
 * Fall 2013 / Spring 2014
 *
 * User board definition - pin numbers, initial configuration, oscillator settings, etc for the 2014 shift board.
 */

#ifndef USER_BOARD_H
#define USER_BOARD_H

#include <conf_board.h>

/*  GPIO  */
// Set each pin number and its initialized settings (input/output, initialized values, pull ups / pull downs, etc)
#define SHIFT_DOWN_PIN		AVR32_PIN_PC02
#define SHIFT_DOWN_CONFIG	GPIO_DIR_OUTPUT | GPIO_INIT_LOW
#define SHIFT_UP_PIN		AVR32_PIN_PC15
#define SHIFT_UP_CONFIG		GPIO_DIR_OUTPUT | GPIO_INIT_LOW // 5-7-16 changed to INIT_HIGH
// clutch exhaust -> re-engage clutch (allows you to drive)
#define CLUTCH_1_PIN		AVR32_PIN_PC16
#define CLUTCH_1_CONFIG		GPIO_DIR_OUTPUT | GPIO_INIT_LOW
// clutch inlet -> disengage clutch (allows you to shift)
#define CLUTCH_0_PIN		AVR32_PIN_PC17
#define CLUTCH_0_CONFIG		GPIO_DIR_OUTPUT | GPIO_INIT_LOW
#define GPIO_X2_PIN			AVR32_PIN_PD27
#define GPIO_X2_CONFIG		GPIO_DIR_OUTPUT | GPIO_INIT_LOW
#define GPIO_X1_PIN			AVR32_PIN_PD28
#define GPIO_X1_CONFIG		GPIO_DIR_OUTPUT | GPIO_INIT_LOW
#define WOT_PIN				AVR32_PIN_PD30
#define WOT_CONFIG			GPIO_DIR_OUTPUT | GPIO_INIT_LOW
#define HWB_PIN				AVR32_PIN_PD21
#define HWB_CONFIG			GPIO_DIR_INPUT

/*  EXT INT  */
// The way in which EIC is defined, EXT_INT0 refers to the 1st pin (Atmel is inconsistent with zero versus one based indexing)
// Use GPIO_DIR_INPUT if you don't want to have any pullup/pulldown
// Auto upshift 2
// No longer an interrupt
#define AUTO_UP_2_EIC			EXT_INT0
#define AUTO_UP_2_FUNCTION		AVR32_EIC_EXTINT_1_3_FUNCTION
#define AUTO_UP_2_PIN			AVR32_EIC_EXTINT_1_3_PIN
#define AUTO_UP_2_IRQ			AVR32_EIC_IRQ_1
#define AUTO_UP_2_CONFIG		GPIO_PULL_UP				// Set pull-up or pull-down
#define AUTO_UP_2_EDGE			EIC_EDGE_FALLING_EDGE		// Set trigger on rising versus falling edge
#define AUTO_UP_2_LEVEL			AVR32_INTC_INT0				// Set interrupt priority (0-3)
#define AUTO_UP_2_EXE			&eic_auto_upshift_2			// Set function to trigger on interrupt
// Gear position sensor
// DOESN'T NEED TO BE AN INTERRUPT
#define GEAR_POS_EIC			EXT_INT1
#define GEAR_POS_FUNCTION		AVR32_EIC_EXTINT_2_2_FUNCTION
#define GEAR_POS_PIN			AVR32_EIC_EXTINT_2_2_PIN
#define GEAR_POS_IRQ			AVR32_EIC_IRQ_2
#define GEAR_POS_CONFIG			GPIO_PULL_UP				// Set pull-up or pull-down
#define GEAR_POS_EDGE			EIC_EDGE_FALLING_EDGE		// Set trigger on rising versus falling edge
#define GEAR_POS_LEVEL			AVR32_INTC_INT0				// Set interrupt priority (0-3)
#define GEAR_POS_EXE			&eic_gear_position_sensor	// Set function to trigger on interrupt
// Auto upshift 1
// No longer an interrupt
#define AUTO_UP_1_EIC			EXT_INT2
#define AUTO_UP_1_FUNCTION		AVR32_EIC_EXTINT_3_1_FUNCTION
#define AUTO_UP_1_PIN			AVR32_EIC_EXTINT_3_1_PIN
#define AUTO_UP_1_IRQ			AVR32_EIC_IRQ_3
#define AUTO_UP_1_CONFIG		GPIO_PULL_UP				// Set pull-up or pull-down
#define AUTO_UP_1_EDGE			EIC_EDGE_FALLING_EDGE		// Set trigger on rising versus falling edge
#define AUTO_UP_1_LEVEL			AVR32_INTC_INT0				// Set interrupt priority (0-3)
#define AUTO_UP_1_EXE			&eic_auto_upshift_1			// Set function to trigger on interrupt
// Downshift paddle
#define DNSHIFT_EIC				EXT_INT3
#define DNSHIFT_FUNCTION		AVR32_EIC_EXTINT_4_1_FUNCTION
#define DNSHIFT_PIN				AVR32_EIC_EXTINT_4_1_PIN
#define DNSHIFT_IRQ				AVR32_EIC_IRQ_4
#define DNSHIFT_CONFIG			GPIO_PULL_UP				// Set pull-up or pull-down
#define DNSHIFT_EDGE			EIC_EDGE_FALLING_EDGE		// Set trigger on rising versus falling edge
#define DNSHIFT_LEVEL			AVR32_INTC_INT0				// Set interrupt priority (0-3)
#define DNSHIFT_EXE				&eic_shift_down				// Set function to trigger on interrupt
// Upshift paddle
#define UPSHIFT_EIC				EXT_INT4
#define UPSHIFT_FUNCTION		AVR32_EIC_EXTINT_5_0_FUNCTION
#define UPSHIFT_PIN				AVR32_EIC_EXTINT_5_0_PIN
#define UPSHIFT_IRQ				AVR32_EIC_IRQ_5
#define UPSHIFT_CONFIG			GPIO_PULL_UP				// Set pull-up or pull-down
#define UPSHIFT_EDGE			EIC_EDGE_FALLING_EDGE		// Set trigger on rising versus falling edge
#define UPSHIFT_LEVEL			AVR32_INTC_INT0				// Set interrupt priority (0-3)
#define UPSHIFT_EXE				&eic_shift_up				// Set function to trigger on interrupt

// Shift enable
// NO LONGER AN INTERRUPT
#define SHIFT_EN_EIC			EXT_INT5
#define SHIFT_EN_FUNCTION		AVR32_EIC_EXTINT_6_1_FUNCTION
#define SHIFT_EN_PIN			AVR32_EIC_EXTINT_6_1_PIN
#define SHIFT_EN_IRQ			AVR32_EIC_IRQ_6
#define SHIFT_EN_CONFIG			GPIO_PULL_UP				// Set pull-up or pull-down
#define SHIFT_EN_EDGE			EIC_EDGE_FALLING_EDGE		// Set trigger on rising versus falling edge
#define SHIFT_EN_LEVEL			AVR32_INTC_INT2				// Set interrupt priority (0-3)
#define SHIFT_EN_EXE			&eic_shift_enable			// Set function to trigger on interrupt

// Neutral toggle
#define NEUTRAL_TOG_EIC			EXT_INT6
#define NEUTRAL_TOG_FUNCTION	AVR32_EIC_EXTINT_7_1_FUNCTION
#define NEUTRAL_TOG_PIN			AVR32_EIC_EXTINT_7_1_PIN
#define NEUTRAL_TOG_IRQ			AVR32_EIC_IRQ_7
#define NEUTRAL_TOG_CONFIG		GPIO_PULL_UP				// Set pull-up or pull-down
#define NEUTRAL_TOG_EDGE		EIC_EDGE_FALLING_EDGE		// Set trigger on rising versus falling edge
#define NEUTRAL_TOG_LEVEL		AVR32_INTC_INT1				// Set interrupt priority (0-3)
#define NEUTRAL_TOG_EXE			&eic_neutral_toggle			// Set function to trigger on interrupt

// Shift pressure
// doesn't need to be an interrupt
#define SHIFT_PRES_EIC			EXT_INT7
#define SHIFT_PRES_FUNCTION		AVR32_EIC_EXTINT_8_1_FUNCTION
#define SHIFT_PRES_PIN			AVR32_EIC_EXTINT_8_1_PIN
#define SHIFT_PRES_IRQ			AVR32_EIC_IRQ_8
#define SHIFT_PRES_CONFIG		GPIO_PULL_UP				// Set pull-up or pull-down
#define SHIFT_PRES_EDGE			EIC_EDGE_FALLING_EDGE		// Set trigger on rising versus falling edge
#define SHIFT_PRES_LEVEL		AVR32_INTC_INT0				// Set interrupt priority (0-3)
#define SHIFT_PRES_EXE			&eic_shift_pressure			// Set function to trigger on interrupt 


/*  PWM  */
#define LED_PWM_PIN				AVR32_PWM_PWML_2_1_PIN		// Pin 43 (PC19)
#define LED_PWM_FUNCTION		AVR32_PWM_PWML_2_1_FUNCTION	// 
#define LED_PWM_ID				2							// PWM #2


/*  SPI  */
#define SPI_CLK_PIN				AVR32_SPI0_SCK_0_0_PIN				// Pin 49
#define SPI_CLK_FUNCTION		AVR32_SPI0_SCK_0_0_FUNCTION
#define SPI_DATA_PIN			AVR32_SPI0_MOSI_0_0_PIN				// Pin 47
#define SPI_DATA_FUNCTION		AVR32_SPI0_MOSI_0_0_FUNCTION
#define CS_LED_PIN				AVR32_PIN_PD11						// Pin 53
#define CS_LED_CONFIG			GPIO_DIR_OUTPUT		// High enable
#define CS_SEV_SEG_PIN			AVR32_PIN_PD03						// Pin 50
#define CS_SEV_SEG_CONFIG		GPIO_DIR_OUTPUT | GPIO_INIT_LOW		// High enable


/*  ADC  */
// Define each ADC pin with its ADC channel and pin function
// Brightness potentiometer
#define BRIGHT_POT_ADC			AVR32_ADCIFA_INP_ADCIN1
#define BRIGHT_POT_PIN			AVR32_ADCIN1_PIN
#define BRIGHT_POT_FUNCTION		AVR32_ADCIN1_FUNCTION
// Clutch position sensor
#define CLUTCH_POS_ADC			AVR32_ADCIFA_INP_ADCIN2
#define CLUTCH_POS_PIN			AVR32_ADCIN2_PIN
#define CLUTCH_POS_FUNCTION		AVR32_ADCIN2_FUNCTION
// Clutch pressure sensor
#define CLUTCH_PRES_ADC			AVR32_ADCIFA_INP_ADCIN3
#define CLUTCH_PRES_PIN			AVR32_ADCIN3_PIN
#define CLUTCH_PRES_FUNCTION	AVR32_ADCIN3_FUNCTION
// Gear Position
// TODO Needs to be added to the gpio_map in adc_shift2014.c,
// get rid of interrupt cruft
// #define GEAR_POS_ADC			AVR32_ADCIFA_INP_ADCIN4	
// #define GEAR_POS_PIN			AVR32_ADCIN4_PIN
// #define GEAR_POS_FUNCTION		AVR32_ADCIN4_FUNCTION
// Extra #3 (ADC_X3)
#define ADC_X3_ADC				AVR32_ADCIFA_INP_ADCIN5
#define ADC_X3_PIN				AVR32_ADCIN5_PIN
#define ADC_X3_FUNCTION			AVR32_ADCIN5_FUNCTION
// Line pressure sensor
#define LINE_PRES_ADC			AVR32_ADCIFA_INN_ADCIN9
#define LINE_PRES_PIN			AVR32_ADCIN9_PIN
#define LINE_PRES_FUNCTION		AVR32_ADCIN9_FUNCTION
// Extra #1 (ADC_X1)
#define ADC_X1_ADC				AVR32_ADCIFA_INN_ADCIN10
#define ADC_X1_PIN				AVR32_AC0BN0_PIN		// ASF doesn't acknowledge this pin
#define ADC_X1_FUNCTION			AVR32_ADCIN9_FUNCTION	// ASF doesn't acknowledge this pin
// Extra #2 (ADC_X2)
#define ADC_X2_ADC				AVR32_ADCIFA_INN_ADCIN11
#define ADC_X2_PIN				AVR32_ADCIN11_PIN
#define ADC_X2_FUNCTION			AVR32_ADCIN11_FUNCTION
// Freq RPM (tach voltage)
#define FREQ_RPM_ADC			AVR32_ADCIFA_INN_ADCIN12
#define FREQ_RPM_PIN			AVR32_ADCIN12_PIN
#define FREQ_RPM_FUNCTION		AVR32_ADCIN12_FUNCTION
// Also need to define the positive and negative pins used as reference
#define ADC_REF_NEG_ADC			AVR32_ADCIFA_INN_ADCIN8
#define ADC_REF_NEG_PIN			AVR32_ADCIN8_PIN
#define ADC_REF_NEG_FUNCTION	AVR32_ADCIN8_FUNCTION
#define ADC_REF_POS_ADC			AVR32_ADCIFA_INP_ADCIN0
#define ADC_REF_POS_PIN			AVR32_ADCIN0_PIN
#define ADC_REF_POS_FUNCTION	AVR32_ADCIN0_FUNCTION


/*  CAN  */
#define CAN_RX_PIN				AVR32_CANIF_RXLINE_0_1_PIN
#define CAN_RX_FUNCTION			AVR32_CANIF_RXLINE_0_1_FUNCTION
#define CAN_TX_PIN				AVR32_CANIF_TXLINE_0_1_PIN
#define CAN_TX_FUNCTION			AVR32_CANIF_TXLINE_0_1_FUNCTION


/* Timer-counter */
#define MILLIS_TC_CHANNEL			0
#define MILLIS_TC_IRQ				AVR32_TC0_IRQ0
#define MILLIS_TC_IRQ_PRIORITY		AVR32_INTC_INT1 // formerly AVR32_INTC_INT0 (2014)
#define TC_FREQUENCY				1000			// 1kHz = 1ms period
													// Max frequency that works is ~100kHz


// External oscillator settings - for USB CDC
#define BOARD_OSC0_HZ           12000000
#define BOARD_OSC0_STARTUP_US   2000
#define BOARD_OSC0_IS_XTAL      true
#define FOSC0					BOARD_OSC0_HZ          //!< Osc0 frequency: Hz.
#define OSC0_STARTUP			BOARD_OSC0_STARTUP_US


#endif // USER_BOARD_H