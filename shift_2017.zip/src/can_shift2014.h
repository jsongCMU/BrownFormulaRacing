/*
 * Brown FSAE Shift System
 * Stephen Weinreich
 * Spring 2014
 *
 * CAN interface, set up in LISTENING mode to read
 * RPM data from the ECU. Cannot write to CAN bus.
 * 
 */

#ifndef _CAN_SHIFT2014_H_
#define _CAN_SHIFT2014_H_
#include <stdint.h>

void can_init_fsae(void);
void can_out_callback_channel0(uint8_t handle, uint8_t event);
uint16_t get_rpm(void);
uint16_t get_tps(void);

#endif