/*
 * Brown FSAE Shift System
 * Stephen Weinreich
 * Fall 2013 / Spring 2014
 *
 * Initialization of USB CDC interface for serial communication over USB.
 *
 */

#ifndef usbcdc_shift2014
#define usbcdc_shift2014

void usb_cdc_init(void);

void read_usb_chars(void);

void reset_to_bootloader(void);

void toggle_pin(uint32_t pin, const char* description);

void read_gear_potentiometer(void);

#endif