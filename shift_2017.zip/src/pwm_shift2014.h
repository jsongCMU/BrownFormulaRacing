/**
 * Brown Formula SAE
 * Stephen Weinreich
 * Fall 2013
 *
 * Easy use of the PWM interface
 *
 */

#ifndef pwm_shift2014
#define pwm_shift2014

// Start PWM
void pwm_init_fsae(void);

// Start a particular PWM channel
void pwm_start(int pin, int function, int channel_id);

// Sets the PWM output to a given duty cycle (0-255)
void pwm_write(int channel_id, int value);

#endif