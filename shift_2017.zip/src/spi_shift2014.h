/*
 * Brown FSAE Shift System
 * Stephen Weinreich
 * Fall 2013 / Spring 2014
 */

#ifndef spi_shift2014
#define spi_shift2014
#include <spi.h>

// Initializes the SPI module
void spi_init(void);

// Write to a shift register
void shiftreg_write(int16_t chip_select_pin, Byte data);

// Returns the byte to be written over SPI in order to write the given gear to the 7seg display.
Byte get_sevseg_byte(int data_to_write);

#endif