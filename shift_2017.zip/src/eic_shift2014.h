/*
 * Brown FSAE Shift System
 * Stephen Weinreich
 * Fall 2013 / Spring 2014
 */

#ifndef eic_shift2014
#define eic_shift2014

// Initializes the EIC
void eic_init_fsae(void);

#endif