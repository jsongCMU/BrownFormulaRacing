/*
 * Brown FSAE Shift System
 * Stephen Weinreich
 * Fall 2013 / Spring 2014
 *
 * Simplify use of the ADC interface.
 *
 */

#ifndef adc_shift2014
#define adc_shift2014

#include <inttypes.h>

// Read and return a value from the ADC
// Takes in the pin which you would like to read, and outputs the value on that pin. Output value ranges 0-4095
int16_t analog_read(int16_t pin);

// Initializes the ADC
void adc_init(void);

#endif
