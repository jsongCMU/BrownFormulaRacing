/*
 * Name: rpm_shift2014.c
 * Date: April 2014
 * Authors: Graham Keeth, based on code written by Jeanette Miranda
 * (Brown FSAE)
 * Description: see rpm_shift2014.h
 */

#include "rpm_shift2014.h"

int get_rpm() {
	
	
	return -1;
}
