/*
 * Name: display_shift2014.c
 * Date: April 2014
 * Authors: Graham Keeth, based on code written by Jeanette Miranda
 * (Brown FSAE)
 * Description: see display_shift2014.h
 */

#include "display_shift2014.h"
#include "can_shift2014.h"
#include "spi_shift2014.h"
#include "user_board.h"
#include "gpio.h"
#include "tc_shift2014.h"
#include <compiler.h>

// EXAMPLES
// 0b00000001 -> **----------, --------
// 0b00000010 -> --**--------, --------
// 0b11000010 -> --**--------, ********

const Byte ALL_OFF =  0b000000000000;

const Byte TOP_1_ON = 0b000000010000;
const Byte TOP_2_ON = 0b000000110000;
const Byte TOP_3_ON = 0b000000111000;
const Byte TOP_4_ON = 0b000000111100;
const Byte TOP_5_ON = 0b000000111110;
const Byte TOP_6_ON = 0b000000111111;

const Byte BLUE_ON =  0b001000000000;
const Byte GREEN_ON = 0b010000000000;
const Byte COLOR_ON = 0b011000000000;

const Byte OIL_ON =   0b000010000000;
const Byte WATER_ON = 0b000001000000;
const Byte ECU_ON =   0b000100000000; 
const Byte ERR_ON =   0b000111000000;



// number of tach LEDs (they're controlled in pairs, so 12 total LEDs)
const int NUMBER_OF_TACH_LEDS = 6;
// number of shift LEDs (controlled in groups of 4, so 8 total LEDs)
const int NUMBER_OF_SHIFT_LEDs = 2;

// min and max RPM values
const int MIN_TACH = 8000;
const int MAX_TACH = 14000;

//min and max TPS values
const int MIN_TPS = 0;
const int MAX_TPS=100;

long map(long x, long in_min, long in_max, long out_min, long out_max) {
	return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
}

long constrain(long x, long min, long max) {
	return (x < min ? min : (x > max ? max : x));
}

void display_digit(int digit) {
	shiftreg_write(CS_SEV_SEG_PIN, get_sevseg_byte(digit));
}

void write_display_leds(uint8_t top, uint8_t bottom, uint8_t error) {
	/*
	 * SHIFTREG BYTE FORMAT:
	 *
	 * 0bxxxxxxxx
	 *
	 * bits 1-2 are for the bottom row
	 * bits 3-8 are for top row
	 *
	 * bottom row of LEDs are enabled/disabled in chunks of 4
	 * top row of LEDs are enabled/disabled in chunks of 2
	 * 1 is enabled, 0 is disabled
	 */
	
	Byte display_value = ALL_OFF;
	
	switch (top) {
		case 1: {
			display_value = display_value | TOP_1_ON;
			break;
		} case 2: {
			display_value = display_value | TOP_2_ON;
			break;
		} case 3: {
			display_value = display_value | TOP_3_ON;
			break;
		} case 4: {
			display_value = display_value | TOP_4_ON;
			break;
		} case 5: {
			display_value = display_value | TOP_5_ON;
			break;
		} case 6: {
			display_value = display_value | TOP_6_ON;
			break;
		} default: {
			break;
		}
	}
	
	switch (bottom) {
		case 1: {
			display_value = display_value | GREEN_ON;
			break;
		} case 2: {
			display_value = display_value | BLUE_ON;
			break;
		} case 3: {
			display_value = display_value | COLOR_ON;
			break;
		} default: {
			break;
		}
	}
	
	switch (error) {
		case 1: {
			display_value = display_value | OIL_ON;
			break;
		} case 2: {
			display_value = display_value | WATER_ON;
			break;
		} case 3: {
			display_value = display_value | ECU_ON;
			break;
		} case 4: {
			display_value = display_value | ERR_ON;
			break;
		} default: {
			break;
		}
	}
	
	shiftreg_write(CS_LED_PIN, display_value);
}

void display_tach(void) {	
	uint16_t last_tach = get_rpm();
	int tach = constrain(last_tach, MIN_TACH, MAX_TACH);
	int num_leds_to_light = map(tach, MIN_TACH, MAX_TACH, 1, NUMBER_OF_TACH_LEDS);
	
	write_display_leds(num_leds_to_light, 0, 0);

}

void display_tps(void) {
	uint16_t tps = get_tps();
	int constrained_tps = constrain(tps, MIN_TPS, MAX_TPS);
	int num_leds_to_light = map(constrained_tps, MIN_TPS, MAX_TPS, 1, NUMBER_OF_TACH_LEDS);
	write_display_leds(num_leds_to_light, 0, 0);
}

void update_leds(uint8_t bottom_leds_to_light) {
	uint16_t last_tach = get_rpm();
	int tach = constrain(last_tach, MIN_TACH, MAX_TACH);
	int num_leds_to_light = map(tach, MIN_TACH, MAX_TACH, 1, NUMBER_OF_TACH_LEDS);
	
	if (bottom_leds_to_light > NUMBER_OF_SHIFT_LEDs) {
		bottom_leds_to_light = NUMBER_OF_SHIFT_LEDs;
	}
	write_display_leds(num_leds_to_light, bottom_leds_to_light, 0);
}

void flash_all_leds(void) {
    // TODO: shorten for enduro?
    for (int i = 0; i < 2; i++) {
	    write_display_leds(6, 2, 0);
		uint32_t current_time = millis();
		while (millis() < current_time + 100); {
			// chill out for a while
		}
	    write_display_leds(0, 0, 0);
		//display_tach();	
		display_tps();
	    current_time = millis();
		while (millis() < current_time + 100) {
			// chill out for a while
		}
	}
}