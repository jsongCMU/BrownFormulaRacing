/*
 * Brown FSAE Shift System
 * Stephen Weinreich
 * Fall 2013 / Spring 2014
 */

#include <asf.h>
#include <board.h>
#include <conf_board.h>
#include <gpio.h>			// For general input/output
#include <spi.h>
#include "spi_shift2014.h"

void spi_init(void)
{
	gpio_map_t SPI_GPIO_MAP =
	{
		{SPI_CLK_PIN, SPI_CLK_FUNCTION},
		{SPI_DATA_PIN, SPI_DATA_FUNCTION}
	};
	
	// SPI options.
	spi_options_t spiOptions =
	{
		.reg          = 0,			// SPI channel to set up
		.baudrate     = 16000000,	// 1MHz baud rate
		.bits         = 8,			// Bits per character (8-16)
		.spck_delay   = 1,			// Delay before first clk pulse after CS, in PBA (12MHz) clk cycles
		.trans_delay  = 0,			// Delay btwn each character, in clk periods
		.stay_act     = 0,			// Sets chip to stay active after last transfer to it
		.spi_mode     = 0,			// See data sheet for SPI modes
		.modfdis      = 1			// Mode fault detection (1 = disable)
	};

	gpio_enable_module(SPI_GPIO_MAP, sizeof(SPI_GPIO_MAP) / sizeof(SPI_GPIO_MAP[0]));		// Assign I/Os to SPI.
	spi_initMaster(&AVR32_SPI0, &spiOptions);				// Initialize as master.
	spi_setupChipReg(&AVR32_SPI0, &spiOptions, 12000000);	// Allow for a chip select (see shiftreg_write fxn)
	spi_selectionMode(&AVR32_SPI0, 0, 0, 0);				// Set SPI selection mode: variable_ps, pcs_decode, delay.
	spi_enable(&AVR32_SPI0);								// Enable SPI module.
}

// Write to a shift register
// Data is send MSB first
void shiftreg_write(int16_t chip_select_pin, Byte data) {
	// Without a call to spi_selectChip, it won't write any data on the lines.
	// This is a lesson is using the appropriate peripheral (TWI) instead of
	// trying to make it work with what you already knew (SPI). The selectChip
	// and unselectChip calls are necessary for the code to run but don't
	// do anything to external pins. Chip selects for the shift registers are
	// done through the calls to the gpio controller.
	gpio_set_gpio_pin(chip_select_pin);
	spi_selectChip(&AVR32_SPI0, 0);
	spi_write(&AVR32_SPI0, data);
	spi_unselectChip(&AVR32_SPI0, 0);
	gpio_clr_gpio_pin(chip_select_pin);
}

/* Returns the byte to be written over SPI in order to write the given gear to the 7seg display.
 * 1-6 return their respective numbers, 0 returns n for neutral, and anything else returns three bars + dp (error)
 * Pins must be grounded to turn the segment on
 * Schematic is wrong. Order (MSB to LSB) is: 0 F B A G C E D (first bit is always zero)
 *    a
 *  f   b
 *    g
 *  e   c
 *    d
 */
Byte get_sevseg_byte(int data_to_write) {
	switch (data_to_write) {
		case 1: return 0b00100100; // 1
		case 2: return 0b00111011; // 2
		case 3: return 0b00111101; // 3
		case 4: return 0b01101100; // 4
		case 5: return 0b01011101; // 5
		case 6: return 0b01011111; // 6
		case 0: return 0b00001110; // n
		default: return 0b00011001; // three bars
	}
}