/*
 * Brown FSAE Shift System
 * Stephen Weinreich
 * Fall 2013 / Spring 2014
 *
 * External interrupt initialization
 */

#include <asf.h>			// To use ASF
#include <gpio.h>			// For general input/output
#include <stdio.h>			// for USB printf
#include <user_board.h>		// Pin definitions
#include <eic.h>
#include <stdbool.h>
#include <stdio.h>
#include "eic_shift2014.h"
#include "usbcdc_shift2014.h" // for reset_to_bootloader()
#include "spi_shift2014.h"
#include "shift_shift2014.h"
#include "tc_shift2014.h"

// minimum time between inputs on the same button that will be accepted
// make bigger to eliminate bouncing, make smaller to increase responsiveness
const uint32_t DEBOUNCE_DELAY = 50; // milliseconds

// time of last shift_up input
uint32_t last_shift_up = 0;

// time of last shift_down input
uint32_t last_shift_down = 0;

// time of last neutral toggle input
uint32_t last_neutral_toggle = 0;

// whether or not shifting is enabled
bool shifting_enabled = true;

/*
__attribute__((__interrupt__)) static void eic_test(void) {
	printf("Interrupt detected!\n");
	eic_clear_interrupt_line(&AVR32_EIC, DNSHIFT_EIC);
	#warning Make sure to clear the correct interrupt or the uC will freeze up
}
*/

/*
__attribute__((__interrupt__)) static void eic_enb_test(void) {
	printf("Shift enable interrupt.\n");
	eic_clear_interrupt_line(&AVR32_EIC, SHIFT_EN_EIC);
	shiftreg_write(CS_LED_PIN, 0b00110011);
	delay_ms(500);
	shiftreg_write(CS_LED_PIN, 0b00001100);
	delay_ms(500);
	shiftreg_write(CS_LED_PIN, 0b00110011);
	delay_ms(500);
	shiftreg_write(CS_LED_PIN, 0b00001100);
	delay_ms(500);
}
*/

/*
__attribute__((__interrupt__)) static void eic_neut_test(void) {
	printf("Neutral toggle interrupt.\n");
	eic_clear_interrupt_line(&AVR32_EIC, NEUTRAL_TOG_EIC);
	shiftreg_write(CS_LED_PIN, 0b11000000);
	delay_ms(500);
	shiftreg_write(CS_LED_PIN, 0b10000000);
	delay_ms(500);
	shiftreg_write(CS_LED_PIN, 0b01000000);
	delay_ms(500);
	shiftreg_write(CS_LED_PIN, 0b11000000);
	delay_ms(500);
}
*/

__attribute__((__interrupt__)) static void eic_shift_enable(void) {
	printf("Shift enable interrupt. Does nothing.\n");
	// does nothing	
	eic_clear_interrupt_line(&AVR32_EIC, SHIFT_EN_EIC);
}

__attribute__((__interrupt__)) static void eic_shift_up(void) {
	printf("Entering upshift interrupt.\n");
	
	if (shifting_enabled) {
		// debounce
		uint32_t current_time = millis();
		if (current_time - last_shift_up > DEBOUNCE_DELAY) { 
			shift_up();
			last_shift_up = current_time;
		}
	}
	
	eic_clear_interrupt_line(&AVR32_EIC, UPSHIFT_EIC);
	printf("Leaving upshift interrupt.\n");
}

__attribute__((__interrupt__)) static void eic_shift_down(void) {
	printf("Entering downshift interrupt.\n");
	
	if (shifting_enabled) {
		// debounce
		uint32_t current_time = millis();
		if (current_time - last_shift_down > DEBOUNCE_DELAY) {
			shift_down();
			last_shift_down = current_time;
		}
	}
	
	eic_clear_interrupt_line(&AVR32_EIC, DNSHIFT_EIC);
	printf("Leaving downshift interrupt.\n");
}

__attribute__((__interrupt__)) static void eic_neutral_toggle(void) {
	printf("Neutral toggle interrupt.\n");
	
	if (shifting_enabled) {
		// debounce
		uint32_t current_time = millis();
		if (current_time - last_shift_down > DEBOUNCE_DELAY) {
			shift_neutral();
			last_neutral_toggle = current_time;
		}
		eic_clear_interrupt_line(&AVR32_EIC, NEUTRAL_TOG_EIC);
	}
}

__attribute__((__interrupt__)) static void eic_gear_position_sensor(void) {
	printf("Gear position sensor interrupt. Does nothing.\n");
	#warning eic_gear_position_sensor has no purpose
	// does nothing - GPS is potentiometer-based, not on/off
	eic_clear_interrupt_line(&AVR32_EIC, GEAR_POS_EIC);
}

 __attribute__((__interrupt__)) static void eic_auto_upshift_2(void) {
	printf("Auto-upshift 2 interrupt. Does nothing.\n");
	#warning eic_auto_upshift_2 has no purpose
	// does nothing - auto_upshift is handled in the main loop
	// for testing clutch (unrelated to auto upshift)
	/*
	gpio_set_gpio_pin(SHIFT_UP_PIN); // close clutch out
	delay_ms(1000);
	gpio_set_gpio_pin(CLUTCH_0_PIN); // open clutch in
	delay_ms(1000);
	gpio_clr_gpio_pin(CLUTCH_0_PIN); // close clutch in
	delay_ms(4000);
	gpio_clr_gpio_pin(SHIFT_UP_PIN); // open clutch out
	*/
	gpio_toggle_pin(SHIFT_UP_PIN); // toggle clutch out
	eic_clear_interrupt_line(&AVR32_EIC, AUTO_UP_2_EIC);
}

__attribute__((__interrupt__)) static void eic_auto_upshift_1(void) {
	printf("Auto-upshift 1 interrupt. Does nothing.\n");
	#warning eic_auto_upshift_1 has no purpose
	// does nothing - auto_upshift is handled in the main loop
	// for testing clutch (unrelated to auto upshift)
	gpio_toggle_pin(CLUTCH_0_PIN); // toggle clutch in
	eic_clear_interrupt_line(&AVR32_EIC, AUTO_UP_1_EIC);
}

__attribute__((__interrupt__)) static void eic_shift_pressure(void) {
	printf("Shift pressure interrupt. Does nothing.\n");
	// does nothing - pressure is an ADC value that gets read
	eic_clear_interrupt_line(&AVR32_EIC, SHIFT_PRES_EIC);
}

void eic_init_fsae(void) {
	eic_options_t eic_options[8];
	// All interrupts are edge triggered, synchronized, and filtered
	for (int i = 0; i < 8; i++) {
		eic_options[i].eic_mode		= EIC_MODE_EDGE_TRIGGERED;	// edge triggered
		eic_options[i].eic_async	= EIC_SYNCH_MODE;			// synchronized to the clock
		eic_options[i].eic_filter	= EIC_FILTER_ENABLED;		// filtered
	}
	// Set individual interrupt lines and rising/falling edge
	eic_options[0].eic_edge		= AUTO_UP_2_EDGE;
	eic_options[0].eic_line		= AUTO_UP_2_EIC;
	eic_options[1].eic_edge		= GEAR_POS_EDGE;
	eic_options[1].eic_line		= GEAR_POS_EIC;
	eic_options[2].eic_edge		= AUTO_UP_1_EDGE;
	eic_options[2].eic_line		= AUTO_UP_1_EIC;
	eic_options[3].eic_edge		= DNSHIFT_EDGE;
	eic_options[3].eic_line		= DNSHIFT_EIC;
	eic_options[4].eic_edge		= UPSHIFT_EDGE;
	eic_options[4].eic_line		= UPSHIFT_EIC;
	eic_options[5].eic_edge		= SHIFT_EN_EDGE;
	eic_options[5].eic_line		= SHIFT_EN_EIC;
	eic_options[6].eic_edge		= NEUTRAL_TOG_EDGE;
	eic_options[6].eic_line		= NEUTRAL_TOG_EIC;
	eic_options[7].eic_edge		= SHIFT_PRES_EDGE;
	eic_options[7].eic_line		= SHIFT_PRES_EIC;

	// Map the interrupt lines to the GPIO pins with the right peripheral functions.
	static const gpio_map_t EIC_GPIO_MAP = {
		{AUTO_UP_2_PIN, AUTO_UP_2_FUNCTION},
		{GEAR_POS_PIN, GEAR_POS_FUNCTION},
		{AUTO_UP_1_PIN, AUTO_UP_1_FUNCTION},
		{DNSHIFT_PIN, DNSHIFT_FUNCTION},
		{UPSHIFT_PIN, UPSHIFT_FUNCTION},
		{SHIFT_EN_PIN, SHIFT_EN_FUNCTION},
		{NEUTRAL_TOG_PIN, NEUTRAL_TOG_FUNCTION},
		{SHIFT_PRES_PIN, SHIFT_PRES_FUNCTION},
	};
	gpio_enable_module(EIC_GPIO_MAP,sizeof(EIC_GPIO_MAP)/sizeof(EIC_GPIO_MAP[0]));

	// Disable all interrupts.
	Disable_global_interrupt();
	
	// Register the EIC interrupt handlers to the interrupt controller.
	INTC_register_interrupt(AUTO_UP_2_EXE, AUTO_UP_2_IRQ, AUTO_UP_2_LEVEL);
	INTC_register_interrupt(GEAR_POS_EXE, GEAR_POS_IRQ, GEAR_POS_LEVEL);
	INTC_register_interrupt(AUTO_UP_1_EXE, AUTO_UP_1_IRQ, AUTO_UP_1_LEVEL);
	INTC_register_interrupt(DNSHIFT_EXE, DNSHIFT_IRQ, DNSHIFT_LEVEL);
	INTC_register_interrupt(UPSHIFT_EXE, UPSHIFT_IRQ, UPSHIFT_LEVEL);
	INTC_register_interrupt(SHIFT_EN_EXE, SHIFT_EN_IRQ, SHIFT_EN_LEVEL);
	INTC_register_interrupt(NEUTRAL_TOG_EXE, NEUTRAL_TOG_IRQ, NEUTRAL_TOG_LEVEL);
	INTC_register_interrupt(SHIFT_PRES_EXE, SHIFT_PRES_IRQ, SHIFT_PRES_LEVEL);
	
	// Init the EIC controller with the options
	eic_init(&AVR32_EIC, eic_options, 8);

	// Enable the chosen lines and their corresponding interrupt feature.
	int mask_lines = 0;
	for (int i = 0; i < 8; i++) {
		mask_lines |= (1 << eic_options[i].eic_line);
	}
	eic_enable_lines(&AVR32_EIC, mask_lines);
	eic_enable_interrupt_lines(&AVR32_EIC, mask_lines);

	// Enable all interrupts.
	Enable_global_interrupt();
}