/*
 * Brown FSAE Shift System
 * Stephen Weinreich
 * Fall 2013 / Spring 2014
 *
 * Using the Timer-Counter to create a 1ms tick.
 *
 */

#include <user_board.h>
#include <gpio.h>			// For general input/output
#include <asf.h>			// To use ASF
#include <tc.h>
#include "tc_shift2014.h"

uint32_t tc_tick = 0;

__attribute__((__interrupt__)) static void tc_irq(void) {
	tc_tick++;									// Increment ms counter
	tc_read_sr(&AVR32_TC0, MILLIS_TC_CHANNEL);	// Clear the interrupt flag
}

void tc_init(void) {
	// All from TC Example 3 on the Atmel website
	// http://asf.atmel.com/docs/2.9.0/avr32.drivers.tc.example3.uc3_a3_xplained/html/tc__example3_8c.html
	
	INTC_register_interrupt(&tc_irq, MILLIS_TC_IRQ, MILLIS_TC_IRQ_PRIORITY);
	
	// Options for waveform generation.
	static const tc_waveform_opt_t waveform_opt = {
		.channel  = MILLIS_TC_CHANNEL,						// Channel selection.
		.bswtrg   = TC_EVT_EFFECT_NOOP,						// Software trigger effect on TIOB
		.beevt    = TC_EVT_EFFECT_NOOP,						// External event effect on TIOB
		.bcpc     = TC_EVT_EFFECT_NOOP,						// RC compare effect on TIOB
		.bcpb     = TC_EVT_EFFECT_NOOP,						// RB compare effect on TIOB.
		.aswtrg   = TC_EVT_EFFECT_NOOP,						// Software trigger effect on TIOA
		.aeevt    = TC_EVT_EFFECT_NOOP,						// External event effect on TIOA
		.acpc     = TC_EVT_EFFECT_NOOP,						// RC compare effect on TIOA.
		.acpa     = TC_EVT_EFFECT_NOOP,						// RA compare effect on TIOA.
		.wavsel   = TC_WAVEFORM_SEL_UP_MODE_RC_TRIGGER,		// Waveform selection: Up mode with automatic trigger(reset) on RC compare
		.enetrg   = false,									// External event trigger enable
		.eevt     = 0,										// External event selection
		.eevtedg  = TC_SEL_NO_EDGE,							// External event edge selection.
		.cpcdis   = false,									// Counter disable when RC compare.
		.cpcstop  = false,									// Counter clock stopped with RC compare.
		.burst    = false,									// Burst signal selection
		.clki     = false,									// Clock inversion
		.tcclks   = TC_CLOCK_SOURCE_TC3						// Internal source clock 3, connected to fPBA / 8.
	};

	// Options for enabling TC interrupts
	static const tc_interrupt_t tc_interrupt = {
		.etrgs = 0,
		.ldrbs = 0,
		.ldras = 0,
		.cpcs  = 1, // Enable interrupt on RC compare alone
		.cpbs  = 0,
		.cpas  = 0,
		.lovrs = 0,
		.covfs = 0
	};
	tc_init_waveform(&AVR32_TC0, &waveform_opt);											// Initialize the timer/counter.
	tc_write_rc(&AVR32_TC0, MILLIS_TC_CHANNEL, (sysclk_get_pba_hz() / 8 / TC_FREQUENCY));	// Set the compare trigger
			// We want: (1 / (fPBA / 8)) * RC = 1 ms, hence RC = (fPBA / 8) / 1000 to get an interrupt every 1 ms.
	tc_configure_interrupts(&AVR32_TC0, MILLIS_TC_CHANNEL, &tc_interrupt);					// Configure the timer interrupt
	tc_start(&AVR32_TC0, MILLIS_TC_CHANNEL);												// Start the timer/counter.
}

// Returns current time in milliseconds, relative to when the board was turned on.
uint32_t millis(void) {
	return tc_tick;
}