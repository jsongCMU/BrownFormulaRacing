/*
 * Brown FSAE Shift System
 * Stephen Weinreich
 * Fall 2013 / Spring 2014
 */

// Header files from ASF
#include <asf.h>			// To use ASF
#include <avr32/io.h>		// IO
#include <delay.h>			// For delays
#include <gpio.h>			// For general input/output
#include <board.h>			// Board pin definitions
#include <string.h>			// For strings
#include <intc.h>
#include <spi.h>
#include <eic.h>
#include <math.h>			// Math constants and functions
#include <stdbool.h>
// FSAE-specific files
#include "adc_shift2014.h"
#include "usbcdc_shift2014.h"
#include "spi_shift2014.h"
#include "pwm_shift2014.h"
#include "eic_shift2014.h"
#include "tc_shift2014.h"
#include "can_shift2014.h"
#include "display_shift2014.h"
#include "shift_shift2014.h"
#include "user_board.h"

extern bool shifting_enabled;
extern uint8_t current_gear;

int main(void) {
	// Board initialization
	board_init();
	
	// initialize gear_i
	//current_gear = read_gps();
	
	// clear all display LEDs and 7-segment
	write_display_leds(6, 2, 0);
	display_digit(0);
	//shift_down();
	// Repeat indefinitely
	int i  = 0;
	while (1) {
		// Read in chars from USB connection
		read_usb_chars();
		
		// display_tps(); // throttle position sensor
		
		// display_tach();
		if(i == 6)
			i = 0;
		write_display_leds(i, i, i);
		
		// Reset to bootloader if HWB is pressed
		/* TODO: This should be moved to an external interrupt. Or, to prevent the vibrations
		 * from accidentally sending us into the bootloader while driving (which may be
		 * hard to get out of), comment this out for the final code. Until then, this is
		 * useful for quick programming. */
		/*
		if (!gpio_get_pin_value(HWB_PIN)) {
			// Write zero to LEDs so they're turned off to protect your eyes
			shiftreg_write(CS_LED_PIN, 0b00000000);
			shiftreg_write(CS_SEV_SEG_PIN, 0b00000000);
			reset_to_bootloader();
		}
		
		// Update LED brightness
		pwm_write(LED_PWM_ID, analog_read(BRIGHT_POT_PIN)/16);
		
		// check if shifting is enabled
		shifting_enabled = gpio_get_pin_value(SHIFT_EN_PIN);
		
		// check if auto-upshift is enabled and upshift if appropriate
		// update tach and shift LEDs
		auto_upshift();	
		*/
	}
}