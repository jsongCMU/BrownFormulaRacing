/*
 * Brown FSAE Shift System
 * Stephen Weinreich
 * Spring 2014
 *
 * CAN interface, set up in LISTENING mode to read
 * RPM data from the ECU. Cannot write to CAN bus.
 * 
 * You need to set conf_can.h clock settings for CAN to work
 * with our clock and bus speeds. For a 12MHz clock:
 *   SJW   1
 *   PRES  1
 *   PRS   0
 *   PHS1  1
 *   PHS2  1
 * 
 */

#include <asf.h>
#include <board.h>
#include <conf_board.h>
#include <gpio.h>
#include <can.h>
#include <canif.h>
#include "can_shift2014.h"

// Local allocation for MOB buffer in HSB_RAM
volatile can_msg_t mob_ram_ch0[NB_MOB_CHANNEL] __attribute__ ((section (".hsb_ram_loc")));

// CAN Message Definition: Rx Message
// Mask for only the ID that we want - the one that includes RPM
can_msg_t msg_rx_listening = {
	{
		{
			.id = 0b000,                      // Identifier
			.id_mask  = 0b110,                // Mask (previously 0b111)
		},
	},
	.data.u64 = 0x0LL,                 // Data
};

// MOB Message Definition: Tx Message
can_mob_t appli_rx_msg = {
	CAN_MOB_NOT_ALLOCATED,            // Handle: by default CAN_MOB_NOT_ALLOCATED
	&msg_rx_listening,                // Pointer on CAN Message
	8,                                // Data length DLC
	CAN_DATA_FRAME,                   // Request type : CAN_DATA_FRAME or CAN_REMOTE_FRAME
	CAN_STATUS_NOT_COMPLETED          // Status: by default CAN_STATUS_NOT_COMPLETED
};

// Save the current RPM value
uint16_t current_rpm = 0;
// Also save the TPS value, for testing
uint16_t current_tps = 0; 
//wheel speed
uint16_t wheel_speed = 0;

// Function called when new RPM data arrives
void can_out_callback_channel0(U8 handle, U8 event) {
	// Extract the data and allow new data to be read
	appli_rx_msg.can_msg->data.u64 = can_get_mob_data(0, handle).u64;
	appli_rx_msg.can_msg->id = can_get_mob_id(0, handle);
	appli_rx_msg.dlc = can_get_mob_dlc(0, handle);
	appli_rx_msg.status = event;
	can_mob_free(0, handle);
	
	// Save the current values that we care about
	if ((appli_rx_msg.can_msg->id & 0x00000007) == 0) {
		current_rpm = (appli_rx_msg.can_msg->data.u8[1] << 8) + appli_rx_msg.can_msg->data.u8[0];
		current_tps = (appli_rx_msg.can_msg->data.u8[3] << 8) + appli_rx_msg.can_msg->data.u8[2];
	} else if ((appli_rx_msg.can_msg->id & 0x00000007) == 1) {
		wheel_speed = (appli_rx_msg.can_msg->data.u8[5] << 8) + appli_rx_msg.can_msg->data.u8[4];
	} else {
		printf("Weird CAN data\n");
	}
}

// Initialize CAN interface
void can_init_fsae(void) {
	// Set up and enable the generic CAN clock
	scif_gc_setup(AVR32_SCIF_GCLK_CANIF,SCIF_GCCTRL_OSC0,AVR32_SCIF_GC_NO_DIV_CLOCK,0);
	scif_gc_enable(AVR32_SCIF_GCLK_CANIF);
	
	// Initialize the CAN pins, assign GPIO
	static const gpio_map_t CAN_GPIO_MAP = {
		{CAN_RX_PIN, CAN_RX_FUNCTION},
		{CAN_TX_PIN, CAN_TX_FUNCTION}
	};
	gpio_enable_module(CAN_GPIO_MAP, sizeof(CAN_GPIO_MAP) / sizeof(CAN_GPIO_MAP[0]));
	
	// Initialize CAN in Listening mode
	can_init(0, ((uint32_t)&mob_ram_ch0[0]), CANIF_CHANNEL_MODE_LISTENING, can_out_callback_channel0);
	
	// Allocate one MOb for RX
	appli_rx_msg.handle = can_mob_alloc(0);

	// Set it up to receive messages
	can_rx(0, appli_rx_msg.handle, appli_rx_msg.req_type, appli_rx_msg.can_msg);
}

// Get most recent RPM value
uint16_t get_rpm(void) {
	return current_rpm;
}

// Get most recent TPS value
uint16_t get_tps(void) {
	return current_tps;
}

