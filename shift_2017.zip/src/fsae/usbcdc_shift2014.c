/*
 * Brown FSAE Shift System
 * Stephen Weinreich
 * Fall 2013 / Spring 2014
 *
 * Initialization of USB CDC interface for serial communication over USB.
 *
 * NOTE: Must change sys clk source to OSC0 in conf_clock.h for USB CDC to function.
 */

#include <asf.h>			// To use ASF
#include <gpio.h>			// For general input/output
#include <board.h>			// Board pin definitions
#include <stdio.h>			// for USB CDC
#include <delay.h>
#include "usbcdc_shift2014.h"
#include "adc_shift2014.h"
#include "display_shift2014.h"
#include "shift_shift2014.h"
#include "can_shift2014.h"

uint8_t ch;		// Character read via USB

// Start up USB CDC connection
void usb_cdc_init(void) {
	// initialize the sleep manager service
	sleepmgr_init();
	// initialize the clock service
	sysclk_init();
	// enable USB stack device
	udc_start();
	stdio_usb_init();
	stdio_usb_enable();
	// Specify that stdout and stdin should not be buffered.
	#if defined(__GNUC__) && defined(__AVR32__)
		setbuf(stdout, NULL);
		setbuf(stdin,  NULL);
	#endif
}

// If pin is high, toggle low. Otherwise toggle high.
void toggle_pin(uint32_t pin, const char* description) {
    if (gpio_get_pin_value(pin)) {
        printf("Set %s low\n", description);
        gpio_clr_gpio_pin(pin);
    }
    else {
        printf("Set %s high\n", description);
        gpio_set_gpio_pin(pin);
    }
}

void read_gear_potentiometer(void) {
    int16_t gear_pos_value = analog_read(GEAR_POS_PIN);
    printf("Gear Potentiometer Value: %" PRId16 "\n", gear_pos_value);
}

// Read characters from USB, act on them if necessary
void read_usb_chars(void) {
	// Read in USB chars and act on them, if there are any
	/*
		* r: Reset to bootloader
		*/
	if (udi_cdc_is_rx_ready()) {
		scanf("%c",&ch); // get one input char
		if (ch) { // make sure it got something
			switch(ch) {
				case 'r': {
					// Reset to bootloader
					printf("Resetting to bootloader...\n");
					delay_ms(2); // Give time to send text to the terminal
					reset_to_bootloader();
					break;
				}
				case '0': {
                    //toggle_pin(CLUTCH_0_PIN, "CL0");
                    break;
				}
				case '1': {
				    //toggle_pin(CLUTCH_1_PIN, "CL1");
                    break;
                /*    
                    // Clutch 1
					if (gpio_get_pin_value(CLUTCH_1_PIN)) {
						printf("Set CL1 low\n");
						gpio_clr_gpio_pin(CLUTCH_1_PIN);
					}
					else {
						printf("Set CL1 high");
						gpio_set_gpio_pin(CLUTCH_1_PIN);
					}
					break;*/
				}
				case 'u': {
                    //toggle_pin(SHIFT_UP_PIN, "SHUP");
					shift_up();
                    break;
                    /*
					// Sh up
					if (gpio_get_pin_value(SHIFT_UP_PIN)) {
						printf("Set SHUP low\n");
						gpio_clr_gpio_pin(SHIFT_UP_PIN);
					}
					else {
						printf("Set SHUP high");
						gpio_set_gpio_pin(SHIFT_UP_PIN);
					}
					break; */
				}
				case 'd': {
                    //toggle_pin(SHIFT_DOWN_PIN, "SHDN");
					shift_down();
                    break;
					/*
                    // Sh dn
					if (gpio_get_pin_value(SHIFT_DOWN_PIN)) {
						printf("Set SHDN low\n");
						gpio_clr_gpio_pin(SHIFT_DOWN_PIN);
					}
					else {
						printf("Set SHDN high");
						gpio_set_gpio_pin(SHIFT_DOWN_PIN);
					}
					break; */
				} case 'g': {
                    read_gear_potentiometer();
                    break;
                } case 't': {
					printf("t invoked. tps=%d, SHIFT_UP_PIN=%d, SHIFT_DOWN_PIN=%d\n", get_tps(), gpio_get_pin_value(SHIFT_UP_PIN), gpio_get_pin_value(SHIFT_DOWN_PIN));
					flash_all_leds();
					break;
				}
				default: {
					 printf("No match to usb char read from host\n");
				}
			}
		}
	}
}

/*
 * Resets the microprocessor into the boot loader for programming.
 */
void reset_to_bootloader() {
	// Set watch dog timeout to 10ms
	wdt_opt_t opt = {
		.us_timeout_period = 10000
	};
	// Disable interrupts
	Disable_global_interrupt();
	// Set address of user page Config Word 1
	volatile unsigned char* config_1_addr = (volatile unsigned char*) 0x808001FC;
	// Write value to user page. E11EFFD7 sets ISP_FORCE high; use E11EFDD9 to set ISP_FORCE low if needed (batchisp will do this automatically)
	flashc_memset32(config_1_addr, 0xE11EFFD7, 4, true);
	// Reset
	wdt_enable(&opt);
}
