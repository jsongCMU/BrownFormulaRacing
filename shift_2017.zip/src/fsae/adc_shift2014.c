/*
 * Brown FSAE Shift System
 * Stephen Weinreich
 * Fall 2013 / Spring 2014
 *
 * Simplify use of the ADC interface.
 *
 */

#include <user_board.h>
#include <adcifa.h>			// For ADC
#include <gpio.h>			// For general input/output
#include <asf.h>			// To use ASF
#include "adc_shift2014.h"

adcifa_sequencer_opt_t adcifa_sequence_opt = { // sequencer configuration
	.convnb						= 8,							// Number of conversions
	.resolution					= ADCIFA_SRES_12B,				// 12 bit resolution
	.trigger_selection			= ADCIFA_TRGSEL_SOFT,			// Software trigger source
	.start_of_conversion		= ADCIFA_SOCB_ALLSEQ,			// Complete sequence on SOC event
	.sh_mode					= ADCIFA_SH_MODE_OVERSAMP,		// Oversampled
	.half_word_adjustment		= ADCIFA_HWLA_NOADJ,			// Disabled
	.software_acknowledge		= ADCIFA_SA_NO_EOS_SOFTACK		// Disable software ack
};
adcifa_opt_t adc_config_t = {
	.frequency					= 32000,			// 32kHz frequency (max)
	.reference_source			= ADCIFA_ADCREF0,	// Reference to 2.5V
	.sample_and_hold_disable	= false,			// Enable sample and hold
	.single_sequencer_mode		= false,			// Split sequencers
	.free_running_mode_enable	= false,			// ??
	.sleep_mode_enable			= false				// Disable sleep mode
};
static const gpio_map_t ADCIFA_GPIO_MAP = {
	{BRIGHT_POT_PIN, BRIGHT_POT_FUNCTION},		// pos
	{CLUTCH_POS_PIN, CLUTCH_POS_FUNCTION},		// pos
	{CLUTCH_PRES_PIN, CLUTCH_PRES_FUNCTION},	// pos
	{ADC_X3_PIN, ADC_X3_FUNCTION},				// pos
	{LINE_PRES_PIN, LINE_PRES_FUNCTION},		// neg
	{ADC_X1_PIN, ADC_X1_FUNCTION},				// neg
	{ADC_X2_PIN, ADC_X2_FUNCTION},				// neg
	{FREQ_RPM_PIN, FREQ_RPM_FUNCTION},			// neg
	{ADC_REF_NEG_PIN, ADC_REF_NEG_FUNCTION},
	{ADC_REF_POS_PIN, ADC_REF_POS_FUNCTION}
};
adcifa_sequencer_conversion_opt_t adcifa_sequence_conversion_opt[8] = { // Conversions in seq config
	{
		.channel_p = BRIGHT_POT_ADC,	// Positive channel
		.channel_n = ADC_REF_NEG_ADC,	// Negative channel
		.gain = ADCIFA_SHG_1			// Gain of 1
	},
	{
		.channel_p = CLUTCH_POS_ADC,	// Positive channel
		.channel_n = ADC_REF_NEG_ADC,	// Negative channel
		.gain = ADCIFA_SHG_1			// Gain of 1
	},
	{
		.channel_p = CLUTCH_PRES_ADC,	// Positive channel
		.channel_n = ADC_REF_NEG_ADC,	// Negative channel
		.gain = ADCIFA_SHG_1			// Gain of 1
	},
	{
		.channel_p = ADC_X3_ADC,		// Positive channel
		.channel_n = ADC_REF_NEG_ADC,	// Negative channel
		.gain = ADCIFA_SHG_1			// Gain of 1
	},
	{
		.channel_p = ADC_REF_POS_ADC,	// Positive channel
		.channel_n = LINE_PRES_ADC,		// Negative channel
		.gain = ADCIFA_SHG_1			// Gain of 1
	},
	{
		.channel_p = ADC_REF_POS_ADC,	// Positive channel
		.channel_n = ADC_X1_ADC,		// Negative channel
		.gain = ADCIFA_SHG_1			// Gain of 1
	},
	{
		.channel_p = ADC_REF_POS_ADC,	// Positive channel
		.channel_n = ADC_X2_ADC,		// Negative channel
		.gain = ADCIFA_SHG_1			// Gain of 1
	},
	{
		.channel_p = ADC_REF_POS_ADC,	// Positive channel
		.channel_n = FREQ_RPM_ADC,		// Negative channel
		.gain = ADCIFA_SHG_1			// Gain of 1
	},
};
int num_el = 0; // Number of ADC pins currently being used


// Read and return a value from the ADC
// Takes in the pin which you would like to read, and outputs the value on that pin. Output value ranges 0-4095
int16_t analog_read(int16_t pin) {
	uint16_t adc_value = 0;
	int16_t pin_index = -1;
	// First, figure out the index of the pin
	// Go through the GPIO map to find the pin, ignoring the last two lines of GPIO map which are reference pins
	for (int i = 0; i < num_el - 2; i++) {
		if (ADCIFA_GPIO_MAP[i].pin == pin) {
			pin_index = i;
			break;
		}
	}
	// If no index was found, print an error and return zero as the ADC value
	if (pin_index == -1) {
		printf("ADC Error: Invalid pin number.");
		return adc_value;
	}
	// Read in all ADC values
	int16_t adc_values[8];
	adcifa_start_sequencer(&AVR32_ADCIFA, 0);
	if (adcifa_get_values_from_sequencer(&AVR32_ADCIFA, 0, &adcifa_sequence_opt, adc_values) == ADCIFA_STATUS_COMPLETED) {
		// Shift to 0 to 4095, rather than centered about 0
		if (pin_index >= 4) { // Value needs to be inverted
			adc_value = (-1*adc_values[pin_index])+2047;
		}
		else {
			adc_value = adc_values[pin_index]+2047;
		}
	}
	// Return the value. If there was an error while reading the sequencer, zero will be returned.
	return adc_value;
}

// Initialize the ADC to read all pins
void adc_init(void) {
	// Switch to osc0
	pcl_switch_to_osc(PCL_OSC0,FOSC0,OSC0_STARTUP);
	
	num_el = sizeof(ADCIFA_GPIO_MAP) / sizeof(ADCIFA_GPIO_MAP[0]);

	// Assign and enable GPIO pins to the ADC function
	gpio_enable_module(ADCIFA_GPIO_MAP, num_el);

	// Configure ADCIFA core, sequencer 0
	adcifa_configure_sequencer(&AVR32_ADCIFA, 0, &adcifa_sequence_opt, adcifa_sequence_conversion_opt);
	adcifa_configure(&AVR32_ADCIFA, &adc_config_t, FOSC0);
}