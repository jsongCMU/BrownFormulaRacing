/*
* Name: shift_shift2014.c
* Date: April 2014
* Authors: Graham Keeth, based on code written by Jeanette Miranda
* (Brown University FSAE)
*
* Description: see shift_shift2014.h
*/

#include "tc_shift2014.h"
#include <delay.h>
#include <stdio.h>
#include <stdbool.h>
#include <stdint.h>
#include <interrupt.h>
#include "shift_shift2014.h"
#include "display_shift2014.h"
#include "can_shift2014.h"
#include "gpio.h"
#include "user_board.h"
#include "adc_shift2014.h"

// whether or not we are using serial commands/reading -> true for debugging, false
// for driving!!!
// determines whether interrupts get disabled during shift functions, which they
// should when we drive.
bool USING_SERIAL = true;

// current gear index. Refers to gear number, not position in engine
// i.e. neutral = 0, 1st = 1
int8_t current_gear = 0; // assume starting in neutral. Updated in main on init

// TODO: might not be necessary, depending on implementation of GPS reader function
// const uint8_t gears[] = {1, 0, 2, 3, 4, 5, 6};

// max number of shifting attempts before considering the attempt a failure
const uint8_t MAX_ATTEMPTS = 2;

// Offset between the RPM at which the 1st shift light comes on and the RPM
// the second shift light comes on (and shifting should occur)
const uint16_t ALMOST_SHIFT_OFFSET = 1000; // RPM

// Engine RPMs at which to upshift during the auto-upshift sequence
const uint16_t auto_upshift_rpms[] = {
	0,      // n to 1
	11500,  // 1 to 2
	11500,  // 2 to 3
	11400,  // 3 to 4
	11400,  // 4 to 5
11300}; // 5 to 6

// max potentiometer values for each gear
// sorted by numerical order, not physical order in the shift cylinder
const double gear_max_gps_value[] = {
	-1, // max value for neutral
	-1, // max value for 1
	-1, // max value for 2
	-1, // max value for 3
	-1, // max value for 4
	-1, // max value for 5
-1}; // max value for 6

// min potentiometer values for each gear
// sorted by numerical order, not physical order in the shift cylinder
const double gear_min_gps_value[] = {
	-1, // max value for neutral
	-1, // max value for 1
	-1, // max value for 2
	-1, // max value for 3
	-1, // max value for 4
	-1, // max value for 5
-1}; // max value for 6

// clutch cylinder pressure if the clutch is engaged. Should be close to atmosphere
const uint32_t clutch_pressure_engaged = 0; // no idea if this is correct. TODO: measure this

// clutch cylinder pressure if the clutch is fully disengaged
const uint32_t clutch_pressure_disengaged = 1000; // no idea if this is correct. TODO: measure this

const int next_gear_min_value = 0; // TODO: do something better
const int next_gear_max_value = 0;

bool shift_up() {
	// interrupts get disabled before solenoids are enabled, and interrupts
	// get enabled again after solenoids get disabled
	printf("Entering shift_up; gpio CLUTCH_1_PIN at %d\n", gpio_get_gpio_pin_output_value(CLUTCH_1_PIN));
	
	/*current_gear = read_gps();
	printf("CURRENT GEAR = %d\n", current_gear);
	// make sure we're not in top gear
	if (current_gear == 6) {
		// flash all lights to notify driver
		flash_all_leds();
		return true; // successful, in a sense
	}
	
	// turn on all display LEDs
	write_display_leds(6, 2);
*/
	//for (int attempt = 0; attempt < MAX_ATTEMPTS; attempt++) {
		// enable upshift solenoid

		/*
		gpio_set_gpio_pin(CLUTCH_1_PIN);
		//printf("set CLUTCH_1_PIN=%d\n", gpio_get_gpio_pin_output_value(CLUTCH_1_PIN));
		delay_ms(500);
		gpio_clr_gpio_pin(CLUTCH_1_PIN);
		*/
		gpio_toggle_pin(CLUTCH_1_PIN);
		//printf("clear CLUTCH_1_PIN\n");

		
		/*
		gpio_set_gpio_pin(SHIFT_UP_PIN); // close clutch out
		delay_ms(1000);
		gpio_set_gpio_pin(CLUTCH_0_PIN); // open clutch in
		delay_ms(1000);
		gpio_clr_gpio_pin(CLUTCH_0_PIN); // close clutch in
		delay_ms(4000);
		gpio_clr_gpio_pin(SHIFT_UP_PIN); // open clutch out
		*/


		// cut engine power
		//gpio_set_gpio_pin(WOT_PIN);
		//printf("set wot_pin\n");
		//delay_ms(20);

		//int counter = 0;
		//int max_counter = 50;

		// wait until we're in gear or 250ms have passed, whichever is first
		//int gear_pos_value = analog_read(GEAR_POS_PIN);
// 		while (gear_pos_value < gear_min_gps_value[current_gear + 1]
// 		&& counter < max_counter) {
// 			delay_ms(5);
// 			gear_pos_value = analog_read(GEAR_POS_PIN);
// 			counter++;
// 		}
		
		// stop shifting up
		
		// success!
		//uint8_t new_gear = read_gps();
		//if (new_gear == current_gear + 1) {
			// in gear -> engine on
			//gpio_clr_gpio_pin(WOT_PIN);
			//printf("clear wot_pin\n");
			
// 			current_gear = read_gps();
// 			display_digit(current_gear);
			// if we haven't shifted up into neutral
// 			if (current_gear != NEUTRAL_I) {
// 				write_display_leds(0, 0);
// 				printf("Leaving shift_up.\n");
// 				return true;
//			}

//			attempt = min(attempt, MAX_ATTEMPTS - 1);
		//}
		
// 		current_gear = read_gps();
// 		display_digit(current_gear);

		//gpio_clr_gpio_pin(WOT_PIN);
		//printf("clear wot_pin\n");
		// wait 50ms and try again
		//delay_ms(50);
//	}
	
// 	current_gear = read_gps();
// 	display_digit(current_gear);
	
	// on fail, flash all LEDs twice
	flash_all_leds();
	
	printf("Leaving shift_up, gpio CLUTCH_1_PIN at %d\n", gpio_get_gpio_pin_output_value(CLUTCH_1_PIN));

	return false;
}

bool shift_down() {
	// interrupts get disabled before solenoids are enabled, and interrupts
	// get enabled again after solenoids get disabled
	printf("Entering shift_down, gpio pin at %d\n", gpio_get_gpio_pin_output_value(SHIFT_DOWN_PIN));
	//current_gear = read_gps();
	//printf("CURRENT GEAR = %d\n", current_gear);
	// if we're in 1st, we can't shift down any more
	/*if (current_gear == 1) {
		// flash the LEDs to notify the driver
		flash_all_leds();
		return true; // successful, in a sense
	}*/
		// re-engage clutch
	
	// turn all display LEDs on
	//write_display_leds(6, 2);
	
	/*
	gpio_set_gpio_pin(SHIFT_DOWN_PIN);
	delay_ms(500);
	gpio_clr_gpio_pin(SHIFT_DOWN_PIN);
	*/
	gpio_toggle_pin(SHIFT_DOWN_PIN);
	/*
	gpio_set_gpio_pin(CLUTCH_0_PIN);
	delay_ms(4000);
	gpio_clr_gpio_pin(CLUTCH_0_PIN);
	*/
	//delay_ms(1000);
	
	// disengage clutch to allow shifting
	/*gpio_set_gpio_pin(CLUTCH_0_PIN);
	printf("set clutch_0 pin\n");*/
	// wait for cylinder to pressurize and clutch to disengage
	//delay_ms(100); // TODO: make this based on clutch sensor values
	
	// stop pressurizing cylinder; clutch is now disengaged
	
	//delay_ms(100);
	//for (int attempt = 0; attempt < MAX_ATTEMPTS; attempt++) {
		//cli(); // disable interrupts
		/*gpio_set_gpio_pin(SHIFT_DOWN_PIN);
		printf("set SHIFT_DOWN_PIN=%d\n", gpio_get_gpio_pin_output_value(SHIFT_DOWN_PIN));*/
		/*
		int counter = 0;
		int max_counter = 50;
		// wait for 250ms or until we're in gear, whichever is first
		int gear_pos_value = analog_read(GEAR_POS_PIN);
		while (gear_pos_value >= gear_max_gps_value[current_gear - 1]
		&& counter < max_counter) {
			delay_ms(5);
			counter++;
		}
		*/
		//delay_ms(100);
		// stop shifting down
		//gpio_clr_gpio_pin(SHIFT_DOWN_PIN);
		//printf("clear shift_down pin\n");
		/*
		uint8_t new_gear = read_gps();
		if (new_gear == current_gear - 1) {
			
			current_gear = read_gps();
			display_digit(current_gear);

			// if the new gear isn't neutral, we're done and we exit. TODO: clutch isn't let out...
			if (current_gear != NEUTRAL_I) {
				// re-engage clutch
				//gpio_set_gpio_pin(CLUTCH_1_PIN);
				//printf("set clutch_1 pin\n");
				// wait for cylinder to vent (TODO: make this based on pressure sensor values)
				delay_ms(80);
				//gpio_clr_gpio_pin(CLUTCH_1_PIN);
				//printf("clear clutch_1 pin\n");
				write_display_leds(0, 0);
				return true;
			}

			// otherwise, we need to try again
			attempt = min(attempt, MAX_ATTEMPTS - 1);
			current_gear = read_gps();
			display_digit(current_gear);
		}
		// wait for engine to rev up
		delay_ms(50);
	}
	
	current_gear = read_gps();
	display_digit(current_gear);
	*/
	/*gpio_clr_gpio_pin(CLUTCH_0_PIN);
	printf("clear clutch_0 pin\n");*/
	
	// flash all LEDs twice
	flash_all_leds();
	//delay_ms(500);

	/*gpio_set_gpio_pin(CLUTCH_1_PIN);
	printf("set clutch_1 pin\n"); */

	// wait for cylinder to vent (TODO: make this based on pressure sensor values)
	//delay_ms(80);
	//delay_ms(500);
	/*gpio_clr_gpio_pin(CLUTCH_1_PIN);
	printf("clear clutch_1 pin\n");*/
	printf("exiting shift_down, %d\n", gpio_get_gpio_pin_output_value(SHIFT_DOWN_PIN));
	return false;
}

void auto_upshift(void) {
	int rpm = get_rpm();
	int current_gear = read_gps();
	
	if (current_gear == 6) {
		update_leds(0);
		} else if (rpm > auto_upshift_rpms[current_gear] - ALMOST_SHIFT_OFFSET) {
		update_leds(1);
		} else if (rpm > auto_upshift_rpms[current_gear]) {
		update_leds(2);
		if ((current_gear < 3) && (gpio_get_pin_value(AUTO_UP_1_PIN) || gpio_get_pin_value(AUTO_UP_2_PIN))) {
			shift_up(); // auto upshift
		}
	}
}

void shift_neutral(void) {
	// interrupts get disabled before solenoids are enabled, and interrupts
	// get enabled again after solenoids get disabled
	
	int current_gear = read_gps();
	if (current_gear != 1) {
		printf("Not in 1st Gear.\n");
		} else {
		//cli(); // disable interrupts
		gpio_set_gpio_pin(SHIFT_UP_PIN);
		delay_ms(10);

		// attempt to shift for 26*500us
		int counter = 0;

		current_gear = read_gps();
		while (current_gear != 0) {
			delay_us(500);
			counter++;
			if (counter > 25) {
				break;
			}
			current_gear = read_gps();
		}

		gpio_clr_gpio_pin(SHIFT_UP_PIN);
		//sei(); // re-enable interrupts
		current_gear = read_gps();
		display_digit(current_gear);
	}
}

int8_t read_gps(void) {
	int16_t gear_pos_value = analog_read(GEAR_POS_PIN);
	
	for (int i = 0; i < 8; i++) {
		if (gear_min_gps_value[i] <= gear_pos_value && gear_max_gps_value[i + 1] > gear_pos_value) {
			return i;
		}
	}
	
	return -1; // not in any of the gears...
}

// TODO: look into cli() to disable interrupts as well as sei() to re-enable them
// another possibility: __attribute__((critical)) ?
void solenoid_on_off(uint32_t solenoid_pin, uint32_t delay) {
	uint32_t current_time = millis();
	gpio_set_gpio_pin(solenoid_pin);
	while (millis() < current_time + delay) {
		// do nothing
	}
	gpio_clr_gpio_pin(solenoid_pin);
	
}
/*
void disable_interrupts(void) {
if (!USING_SERIAL) {
cli();
}
}
*/
/*
void enable_interrupts(void) {
if (!USING_SERIAL) {
sei();
}
}
*/