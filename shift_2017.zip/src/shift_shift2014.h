/*
 * Name: shift_shift2014.h
 * Date: April 2014
 * Authors: Graham Keeth, based on code written by Jeanette Miranda
 * (Brown University FSAE)
 *
 * Description: Code for all primary shifting functions
 * - upshifts
 * - downshifts
 * - auto-upshift functionality (for drag)
 * - shifting into neutral
 *
 * Also contains definitions/macros for gear indices and optimal shifting RPMs.
 */

#ifndef SHIFT_SHIFT2014_H
#define SHIFT_SHIFT2014_H

#include <stdbool.h>

#define IN_GEAR 0
#define OUT_OF_GEAR 1

// indices for neutral, first, and half-neutral
// half-neutral is no longer necessary with 2014's switch to a potentiometer
// -based gear position sensor
#define NEUTRAL_I 0
#define FIRST_I 1
// #define HALF_I 5

/*
 * shifts up 1 gear. If the gear change is unsuccessful after max_attempts 
 * attempts, returns false in original gear. 
 * NOTE: disables interrupts during parts of function
 */
bool shift_up(void);

/*
 * shifts down 1 gear. If the gear change is unsuccessful after max_attempts 
 * attempts, returns false in original gear.
 * NOTE: disables interrupts during parts of function
 */
bool shift_down(void);

/*
 * Updates shift lights when the RPM is near or at a shift point. While auto
 * upshift button is pressed, automatically upshifts at shift points.
 * Optimal shift points are set by auto_upshift_rpms[] in shift_shift2014.c
 * Useful for drag.
 * Also updates tach LEDs.
 */
void auto_upshift(void);

/*
 * shifts from 1st gear into neutral.
 * NOTE: disables interrupts during parts of function
 */
void shift_neutral(void);

/*
 * returns the current gear by reading the gear position sensor
 */
int8_t read_gps(void);

/*
 * turns the solenoid at the given pin on and off again, with a given delay in the middle
 */
void solenoid_on_off(uint32_t solenoid_pin, uint32_t delay);

/*
 * disables interrupts. Only functions when the USING_SERIAL flag is set to false
 */
void disable_interrupts(void);

/*
 * enables interrupts. Only functions when the USING_SERIAL flag is set to true
 */
void enable_interrupts(void);

#endif
