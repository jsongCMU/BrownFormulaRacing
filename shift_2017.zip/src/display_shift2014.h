/*
 * Name: display_shift2014.h
 * Date: April 2014
 * Authors: Graham Keeth, based on code written by Jeanette Miranda
 * (Brown FSAE)
 *
 * Description: code for controlling and activating all display functions
 * (tach LEDs, extra LEDs, 7 segment display)
 */

#ifndef DISPLAY_SHIFT2014_H
#define DISPLAY_SHIFT2014_H

#include <stdint.h>

// scales a value from the input range to the output range
// copied from Arduino website. consider putting this somewhere more useful
long map(long x, long in_min, long in_max, long out_min, long out_max);

// constrains x between min and max
long constrain(long x, long min, long max);

// displays a given digit on the 7-segment display
void display_digit(int digit);

// illuminates a given number of top and bottom display LEDs
// top: between 0 and 6, inclusive, from left to right (accumulating)
// bottom: between 0 and 2, inclusive, from left to right (accumulating)
void write_display_leds(uint8_t top, uint8_t bottom, uint8_t error);

// displays the last RPM value on the tachometer LEDs. If the rpm is lower than
// min_tach, then only 2 LEDs are lit. The 6 pairs of 2 LEDs are split between min_tach and max_tach.
// TODO: probably unnecessary
void display_tach(void);

// displays the last RPM value on the tachometer LEDs and lights up the given
// number of shift LEDs (0, 1, 2). If the rpm is lower than min_tach, then only 
// 2 LEDs are lit. The 6 pairs of 2 LEDs are evenly spaced between min_tach and 
// max_tach. 
void update_leds(uint8_t bottom_leds_to_light);

// flashes all shift LEDs on the face of the board (including tach) twice. 
// intended for use when shifts fail
void flash_all_leds(void);

void display_tps(void);

#endif // DISPLAY_SHIFT2014_H
